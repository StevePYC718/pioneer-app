# Pioneer App UX Updates - Integration Guide

## Overview

These components incorporate the best patterns from Noom Mood and Headspace based on your competitive research. Here's how to integrate them into your existing app.

---

## New Components

### 1. EnergyCheckIn.tsx
**What it does:** Asks users how their energy is before showing the lesson. Calibrates the experience.

**Where to use:** Home screen, shown once daily before the main content.

**Integration:**
```tsx
import EnergyCheckIn from './components/EnergyCheckIn';

// In your HomeScreen
const [hasCheckedIn, setHasCheckedIn] = useState(false);
const [energyLevel, setEnergyLevel] = useState<number | null>(null);

// Check if user has checked in today (store in AsyncStorage or your backend)
useEffect(() => {
  checkTodayCheckIn().then(setHasCheckedIn);
}, []);

// If not checked in, show the check-in first
if (!hasCheckedIn) {
  return (
    <EnergyCheckIn
      userName={user.firstName}
      onComplete={(level) => {
        setEnergyLevel(level);
        saveTodayCheckIn(level);
        setHasCheckedIn(true);
      }}
    />
  );
}
```

---

### 2. PaginatedLesson.tsx
**What it does:** Replaces scrolling lesson content with Noom-style swipeable cards.

**Key features:**
- Dot navigation at bottom
- Progress bar at top
- Highlighted text (mint green background)
- Playful CTA buttons ("LET'S GO", "NICE", "GOT IT")
- Expandable exercise prompts

**Integration:**
```tsx
import PaginatedLesson from './components/PaginatedLesson';

// Define your lesson content as cards
const LESSON_1_CARDS = [
  {
    id: 1,
    type: 'intro',
    title: 'Fear',
    content: 'Today we\'re going to talk about fear...',
    image: 'lesson1_intro.jpg',
    ctaText: 'LET\'S GO',
  },
  {
    id: 2,
    type: 'content',
    content: 'Fear shows up in creative work wearing different disguises...',
    highlightedContent: 'Fear loves to dress up as something productive.',
    ctaText: 'OKAY',
  },
  // ... more cards
];

// Use in your LessonScreen
<PaginatedLesson
  lessonTitle="Fear"
  lessonSubtitle="Spot how fear hides in your creative work"
  sprintNumber={1}
  lessonNumber={1}
  cards={LESSON_1_CARDS}
  onComplete={() => navigation.navigate('Home')}
  onBack={() => navigation.goBack()}
/>
```

---

### 3. AICoPilot.tsx
**What it does:** Headspace Ebb-style chat interface with avatar and suggested prompts.

**Key features:**
- Animated avatar (orange sun face like Ebb)
- Context-aware greeting based on energy/sprint/progress
- Suggested prompt chips
- Thumbs up/down feedback
- Typing indicator

**Integration:**
```tsx
import AICoPilot from './components/AICoPilot';

// Add to your navigation
<Stack.Screen name="CoPilot" component={CoPilotScreen} />

// CoPilotScreen.tsx
export default function CoPilotScreen() {
  const { user, stats } = useUserContext();
  const navigation = useNavigation();
  
  return (
    <AICoPilot
      userName={user.firstName}
      currentEnergy={stats.todayEnergy}
      currentSprint={stats.currentSprint}
      lessonsCompleted={stats.lessonsCompleted}
      onClose={() => navigation.goBack()}
    />
  );
}

// For actual AI responses, replace generateResponse() with your API call:
const generateResponse = async (userInput: string): Promise<string> => {
  const response = await fetch('YOUR_AI_ENDPOINT', {
    method: 'POST',
    body: JSON.stringify({
      message: userInput,
      context: {
        userName: userName,
        currentSprint: currentSprint,
        energyLevel: currentEnergy,
      },
    }),
  });
  return response.json();
};
```

---

### 4. EnhancedProfile.tsx
**What it does:** Upgraded profile with Headspace-style gradient header, streak calendar, and journey progress.

**Key features:**
- Colorful gradient header
- 4-stat grid (streak, lessons, minutes, best streak)
- 7-day streak calendar visualization
- 90-day journey progress bar with phase milestones

**Integration:**
```tsx
import EnhancedProfile from './components/EnhancedProfile';

// Replace your current Profile screen
<EnhancedProfile
  userName={user.name}
  userEmail={user.email}
  joinDate="November 2025"
  stats={{
    currentStreak: user.currentStreak,
    longestStreak: user.longestStreak,
    lessonsCompleted: user.lessonsCompleted,
    totalMinutes: user.totalMinutes,
    sprintsCompleted: user.sprintsCompleted,
  }}
  streakDays={[true, true, true, false, true, true, false]} // Last 7 days
  onSignOut={handleSignOut}
  onSettings={() => navigation.navigate('Settings')}
/>
```

---

### 5. EnhancedHomeScreen.tsx
**What it does:** Updated home screen that integrates energy check-in and Co-Pilot access.

**Key features:**
- Energy check-in flow (shows first if not completed today)
- Main lesson card with progress dots
- Co-Pilot quick access card with avatar
- Today's micro-action card
- Motivational quote section

**Integration:**
```tsx
import EnhancedHomeScreen from './components/EnhancedHomeScreen';

// Replace your current HomeScreen
<EnhancedHomeScreen
  userName={user.firstName}
  currentStreak={user.currentStreak}
  currentLesson={{
    id: 2,
    title: 'Resistance',
    subtitle: 'Catch yourself procrastinating and do the real work instead.',
    duration: '12 min',
    sprintNumber: 1,
    lessonNumber: 2,
  }}
  todayMicroAction="Complete your Resistance Pattern Map (10 min)"
  hasCheckedInToday={hasCheckedIn}
  lessonProgress={1} // 0, 1, or 2 for Sprint 1
  onStartLesson={() => navigation.navigate('Lesson')}
  onOpenCoPilot={() => navigation.navigate('CoPilot')}
  onEnergyCheckIn={handleEnergyCheckIn}
/>
```

---

## Required Dependencies

Make sure you have these installed:

```bash
npx expo install expo-linear-gradient
npx expo install @expo/vector-icons
```

---

## Data Structure Recommendations

### Lesson Cards Schema
```typescript
interface LessonCard {
  id: number;
  type: 'intro' | 'content' | 'exercise' | 'audio' | 'reflection' | 'complete';
  title?: string;
  content?: string;
  highlightedContent?: string;  // Gets mint green background
  image?: string;
  audioUrl?: string;
  audioDuration?: string;
  exercisePrompts?: string[];   // Expandable accordion items
  ctaText: string;              // Button text
}
```

### User Stats Schema
```typescript
interface UserStats {
  currentStreak: number;
  longestStreak: number;
  lessonsCompleted: number;
  totalMinutes: number;
  sprintsCompleted: number;
  todayEnergy?: number;        // 1-5, set from check-in
  hasCheckedInToday: boolean;
}
```

---

## Quick Wins (Do First)

1. **Add energy check-in** - Biggest behavioral design impact, sets tone for the day
2. **Add Co-Pilot card to home** - Differentiator, even without real AI behind it
3. **Upgrade profile** - Low effort, high visual impact
4. **Convert Lesson 1 to cards** - Test paginated format before doing all lessons

---

## Color Reference

```typescript
const COLORS = {
  // Backgrounds
  background: '#0F0F1A',
  surface: '#1E1E2E',
  surfaceBorder: '#2D2D3D',
  
  // Primary
  primary: '#8B5CF6',      // Purple (your existing)
  primaryDark: '#7C3AED',
  
  // Accent
  accent: '#F97316',       // Orange (Co-Pilot)
  accentLight: '#FB923C',
  
  // Energy indicators
  energyLow: '#EF4444',
  energyMedLow: '#F97316',
  energyMedium: '#EAB308',
  energyGood: '#22C55E',
  energyHigh: '#8B5CF6',
  
  // Text
  text: '#FFFFFF',
  textSecondary: '#D1D5DB',
  textTertiary: '#9CA3AF',
  textMuted: '#6B7280',
  
  // Highlights
  highlight: '#99F6E4',    // Mint green (Noom-style)
  
  // Status
  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',
};
```

---

## Questions?

These components are designed to drop into your existing navigation structure. The main integration points are:

1. Home screen → EnhancedHomeScreen
2. Lesson screen → PaginatedLesson
3. Profile screen → EnhancedProfile
4. New screen → AICoPilot (add to tab bar or as modal)

Let me know if you need help with any specific integration!
