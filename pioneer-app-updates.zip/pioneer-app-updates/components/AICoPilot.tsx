// AICoPilot.tsx
// New screen - Ebb-style AI chat interface with avatar and suggested prompts

import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AICoPilotProps {
  userName: string;
  currentEnergy?: number;
  currentSprint?: number;
  lessonsCompleted?: number;
  onClose: () => void;
}

// Suggested prompts based on user context
const getSuggestedPrompts = (energy?: number, sprint?: number): string[] => {
  const basePrompts = [
    "I'm feeling stuck",
    "What should I focus on?",
    "Help me get started",
  ];
  
  if (energy && energy <= 2) {
    return [
      "I'm feeling overwhelmed",
      "Give me something small",
      "I need encouragement",
    ];
  }
  
  if (sprint === 1) {
    return [
      "Help me with fear",
      "I keep procrastinating",
      "I don't feel ready",
    ];
  }
  
  return basePrompts;
};

// Avatar component with animated glow
const CoPilotAvatar: React.FC<{ isThinking?: boolean }> = ({ isThinking }) => {
  const pulseAnim = useRef(new Animated.Value(1)).current;
  
  useEffect(() => {
    if (isThinking) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isThinking]);
  
  return (
    <Animated.View style={[styles.avatarContainer, { transform: [{ scale: pulseAnim }] }]}>
      <LinearGradient
        colors={['#F97316', '#FB923C', '#FDBA74']}
        style={styles.avatar}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        {/* Simple face */}
        <View style={styles.faceContainer}>
          <View style={styles.eyesContainer}>
            <View style={styles.eye} />
            <View style={styles.eye} />
          </View>
          <View style={styles.smile} />
        </View>
      </LinearGradient>
    </Animated.View>
  );
};

export const AICoPilot: React.FC<AICoPilotProps> = ({
  userName,
  currentEnergy,
  currentSprint,
  lessonsCompleted,
  onClose,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  
  const suggestedPrompts = getSuggestedPrompts(currentEnergy, currentSprint);
  
  // Initial greeting based on context
  useEffect(() => {
    const greeting = getContextualGreeting();
    setMessages([{
      id: '1',
      role: 'assistant',
      content: greeting,
      timestamp: new Date(),
    }]);
  }, []);
  
  const getContextualGreeting = (): string => {
    const hour = new Date().getHours();
    const timeGreeting = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    
    if (currentEnergy && currentEnergy <= 2) {
      return `Hey ${userName}. I noticed your energy is low today. That's totally okay—we can work with that. What's on your mind?`;
    }
    
    if (lessonsCompleted === 0) {
      return `Hi ${userName}! Welcome to your first day. I'm here to help you navigate the journey. Feeling nervous, excited, or something else?`;
    }
    
    if (currentSprint === 1) {
      return `Good ${timeGreeting}, ${userName}! How's Sprint 1 treating you? Any blocks coming up I can help with?`;
    }
    
    return `Hey ${userName}! Good ${timeGreeting}. How are you feeling about your progress today?`;
  };
  
  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsThinking(true);
    
    // Scroll to bottom
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
    
    // Simulate AI response (replace with actual API call)
    setTimeout(() => {
      const response = generateResponse(text);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsThinking(false);
      
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }, 1500);
  };
  
  // Simple response logic (replace with actual AI)
  const generateResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('stuck') || input.includes('frozen')) {
      return "Feeling stuck is a signal, not a stop sign. Usually it means the task feels too big. What's the smallest possible version of what you're trying to do? Like, if the task is 'write a proposal,' the smallest version might be 'open a blank document and write one sentence.'";
    }
    
    if (input.includes('procrastinat')) {
      return "Procrastination is usually fear wearing a productivity mask. What's the thing you're avoiding? Sometimes just naming it takes away some of its power.";
    }
    
    if (input.includes('overwhelm') || input.includes('too much')) {
      return "When everything feels like too much, the answer is almost always: do less, but do it. Pick ONE thing. Not the most important thing—the easiest thing that still moves you forward. What's that one thing right now?";
    }
    
    if (input.includes('tired') || input.includes('exhausted')) {
      return "Rest is part of the work. On low-energy days, the goal isn't productivity—it's maintaining the streak. Even 5 minutes of intentional action counts. What's something you could do in 5 minutes that would feel like a win?";
    }
    
    if (input.includes('focus') || input.includes('what should')) {
      return "Here's what I'd suggest: Look at your current micro-action for today. If you haven't done it yet, that's your focus. If you have, you've already won today. Anything else is bonus.";
    }
    
    return "I hear you. Tell me more about what's coming up for you. The more specific you can be, the more I can help.";
  };
  
  const handlePromptTap = (prompt: string) => {
    handleSend(prompt);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <Ionicons name="ellipsis-horizontal" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <View style={styles.headerSpacer} />
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <Ionicons name="close" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
      
      {/* Avatar */}
      <View style={styles.avatarSection}>
        <CoPilotAvatar isThinking={isThinking} />
      </View>
      
      {/* Messages */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.messagesContainer}
        keyboardVerticalOffset={100}
      >
        <ScrollView
          ref={scrollViewRef}
          style={styles.messagesScrollView}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageBubble,
                message.role === 'user' ? styles.userMessage : styles.assistantMessage,
              ]}
            >
              {message.role === 'assistant' && (
                <View style={styles.assistantLabel}>
                  <View style={styles.assistantDot} />
                  <Text style={styles.assistantName}>Co-Pilot</Text>
                </View>
              )}
              <Text style={styles.messageText}>{message.content}</Text>
              
              {/* Feedback buttons for assistant messages */}
              {message.role === 'assistant' && (
                <View style={styles.feedbackButtons}>
                  <TouchableOpacity style={styles.feedbackButton}>
                    <Ionicons name="thumbs-up-outline" size={18} color="#6B7280" />
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.feedbackButton}>
                    <Ionicons name="thumbs-down-outline" size={18} color="#6B7280" />
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))}
          
          {isThinking && (
            <View style={[styles.messageBubble, styles.assistantMessage]}>
              <View style={styles.thinkingDots}>
                <View style={styles.thinkingDot} />
                <View style={[styles.thinkingDot, { marginHorizontal: 4 }]} />
                <View style={styles.thinkingDot} />
              </View>
            </View>
          )}
        </ScrollView>
        
        {/* Suggested Prompts */}
        {messages.length <= 1 && (
          <View style={styles.promptsSection}>
            <Text style={styles.promptsLabel}>Explore more with Co-Pilot</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.promptsContainer}
            >
              {suggestedPrompts.map((prompt, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.promptChip}
                  onPress={() => handlePromptTap(prompt)}
                >
                  <Text style={styles.promptChipText}>{prompt}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}
        
        {/* Input */}
        <View style={styles.inputContainer}>
          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.input}
              placeholder="Share your thoughts..."
              placeholderTextColor="#6B7280"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
            />
            <TouchableOpacity
              style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
              onPress={() => handleSend(inputText)}
              disabled={!inputText.trim()}
            >
              <Ionicons
                name="arrow-up"
                size={20}
                color={inputText.trim() ? '#FFFFFF' : '#4B5563'}
              />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F1A',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
  },
  closeButton: {
    padding: 8,
  },
  headerSpacer: {
    flex: 1,
  },
  avatarSection: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    shadowColor: '#F97316',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 10,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  faceContainer: {
    alignItems: 'center',
  },
  eyesContainer: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  eye: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#1F2937',
    marginHorizontal: 10,
  },
  smile: {
    width: 24,
    height: 12,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
    borderWidth: 3,
    borderTopWidth: 0,
    borderColor: '#1F2937',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesScrollView: {
    flex: 1,
  },
  messagesContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  messageBubble: {
    marginVertical: 8,
    padding: 16,
    borderRadius: 20,
    maxWidth: '85%',
  },
  userMessage: {
    backgroundColor: '#8B5CF6',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  assistantMessage: {
    backgroundColor: '#1E1E2E',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  assistantLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  assistantDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#F97316',
    marginRight: 8,
  },
  assistantName: {
    fontSize: 12,
    color: '#9CA3AF',
    fontWeight: '600',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#FFFFFF',
  },
  feedbackButtons: {
    flexDirection: 'row',
    marginTop: 12,
  },
  feedbackButton: {
    padding: 4,
    marginRight: 12,
  },
  thinkingDots: {
    flexDirection: 'row',
    padding: 8,
  },
  thinkingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#6B7280',
  },
  promptsSection: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  promptsLabel: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 12,
  },
  promptsContainer: {
    paddingRight: 16,
  },
  promptChip: {
    backgroundColor: '#1E1E2E',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  promptChipText: {
    fontSize: 14,
    color: '#D1D5DB',
  },
  inputContainer: {
    paddingHorizontal: 16,
    paddingBottom: 40,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#2D2D3D',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#1E1E2E',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#FFFFFF',
    maxHeight: 100,
    paddingVertical: 8,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  sendButtonDisabled: {
    backgroundColor: '#2D2D3D',
  },
});

export default AICoPilot;
