// PaginatedLesson.tsx
// Replaces your current lesson content view with Noom-style swipeable cards

import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ScrollView,
  Image,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Highlighted text component (mint green background like Noom)
const HighlightedText: React.FC<{ children: string }> = ({ children }) => (
  <Text style={styles.highlightedText}>{children}</Text>
);

interface LessonCard {
  id: number;
  type: 'intro' | 'content' | 'exercise' | 'audio' | 'reflection' | 'complete';
  title?: string;
  content?: string;
  highlightedContent?: string;
  image?: string;
  audioUrl?: string;
  audioDuration?: string;
  exercisePrompts?: string[];
  ctaText: string;
}

interface PaginatedLessonProps {
  lessonTitle: string;
  lessonSubtitle: string;
  sprintNumber: number;
  lessonNumber: number;
  cards: LessonCard[];
  onComplete: () => void;
  onBack: () => void;
}

// Playful CTA button texts based on card type
const getCtaText = (cardType: string, isLast: boolean): string => {
  if (isLast) return "I'M READY";
  
  const ctaOptions: Record<string, string[]> = {
    intro: ['LET\'S GO', 'I\'M IN', 'SHOW ME'],
    content: ['NEXT', 'GOT IT', 'OKAY'],
    exercise: ['DONE', 'FINISHED', 'CHECK'],
    audio: ['LISTENED', 'COMPLETE', 'NEXT'],
    reflection: ['NOTED', 'SAVED', 'NEXT'],
  };
  
  const options = ctaOptions[cardType] || ['NEXT'];
  return options[Math.floor(Math.random() * options.length)];
};

export const PaginatedLesson: React.FC<PaginatedLessonProps> = ({
  lessonTitle,
  lessonSubtitle,
  sprintNumber,
  lessonNumber,
  cards,
  onComplete,
  onBack,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  const progressAnim = useRef(new Animated.Value(0)).current;

  const totalCards = cards.length;
  const isLastCard = currentIndex === totalCards - 1;
  const currentCard = cards[currentIndex];

  const goToNext = () => {
    if (isLastCard) {
      onComplete();
      return;
    }
    
    const nextIndex = currentIndex + 1;
    setCurrentIndex(nextIndex);
    
    // Animate progress
    Animated.timing(progressAnim, {
      toValue: nextIndex / (totalCards - 1),
      duration: 300,
      useNativeDriver: false,
    }).start();
    
    // Scroll to next card
    scrollViewRef.current?.scrollTo({
      x: nextIndex * SCREEN_WIDTH,
      animated: true,
    });
  };

  const goToPrevious = () => {
    if (currentIndex === 0) {
      onBack();
      return;
    }
    
    const prevIndex = currentIndex - 1;
    setCurrentIndex(prevIndex);
    
    Animated.timing(progressAnim, {
      toValue: prevIndex / (totalCards - 1),
      duration: 300,
      useNativeDriver: false,
    }).start();
    
    scrollViewRef.current?.scrollTo({
      x: prevIndex * SCREEN_WIDTH,
      animated: true,
    });
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  const renderCard = (card: LessonCard, index: number) => {
    return (
      <View key={card.id} style={styles.cardContainer}>
        {/* Card Image */}
        {card.image && (
          <View style={styles.imageContainer}>
            <View style={styles.imagePlaceholder}>
              {/* Replace with actual Image component when you have images */}
              <Ionicons name="image-outline" size={48} color="#4B5563" />
            </View>
          </View>
        )}
        
        {/* Card Content */}
        <View style={styles.cardContent}>
          {card.title && (
            <Text style={styles.cardTitle}>{card.title}</Text>
          )}
          
          {card.content && (
            <Text style={styles.cardText}>{card.content}</Text>
          )}
          
          {card.highlightedContent && (
            <View style={styles.highlightContainer}>
              <HighlightedText>{card.highlightedContent}</HighlightedText>
            </View>
          )}
          
          {/* Audio Player */}
          {card.type === 'audio' && (
            <View style={styles.audioPlayer}>
              <TouchableOpacity style={styles.playButton}>
                <Ionicons name="play" size={32} color="#FFFFFF" />
              </TouchableOpacity>
              <Text style={styles.audioDuration}>{card.audioDuration || '12 min'}</Text>
            </View>
          )}
          
          {/* Exercise Prompts - Expandable Accordions like Noom */}
          {card.exercisePrompts && (
            <View style={styles.promptsContainer}>
              {card.exercisePrompts.map((prompt, i) => (
                <TouchableOpacity key={i} style={styles.promptItem}>
                  <Ionicons name="chevron-forward" size={20} color="#8B5CF6" />
                  <Text style={styles.promptText}>{prompt}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={goToPrevious} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        
        <View style={styles.headerCenter}>
          <Text style={styles.headerLabel}>
            SPRINT {sprintNumber} • LESSON {lessonNumber}
          </Text>
          <Text style={styles.headerTitle}>{lessonTitle}</Text>
        </View>
        
        <TouchableOpacity style={styles.bookmarkButton}>
          <Ionicons name="bookmark-outline" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
      
      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <Animated.View style={[styles.progressBar, { width: progressWidth }]} />
      </View>
      
      {/* Swipeable Cards */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEnabled={false}
        style={styles.cardsScrollView}
      >
        {cards.map((card, index) => renderCard(card, index))}
      </ScrollView>
      
      {/* Bottom Section */}
      <View style={styles.bottomSection}>
        {/* Dot Indicators */}
        <View style={styles.dotsContainer}>
          {cards.map((_, index) => (
            <View
              key={index}
              style={[
                styles.dot,
                index === currentIndex && styles.dotActive,
                index < currentIndex && styles.dotCompleted,
              ]}
            />
          ))}
        </View>
        
        {/* CTA Button */}
        <TouchableOpacity
          style={styles.ctaButton}
          onPress={goToNext}
          activeOpacity={0.8}
        >
          <Text style={styles.ctaText}>
            {isLastCard ? "I'M READY" : currentCard.ctaText}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F1A',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 16,
  },
  backButton: {
    padding: 8,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerLabel: {
    fontSize: 12,
    color: '#6B7280',
    letterSpacing: 1,
    marginBottom: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  bookmarkButton: {
    padding: 8,
  },
  progressContainer: {
    height: 3,
    backgroundColor: '#2D2D3D',
    marginHorizontal: 16,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#8B5CF6',
    borderRadius: 2,
  },
  cardsScrollView: {
    flex: 1,
  },
  cardContainer: {
    width: SCREEN_WIDTH,
    flex: 1,
  },
  imageContainer: {
    height: 200,
    marginHorizontal: 16,
    marginTop: 24,
    borderRadius: 16,
    overflow: 'hidden',
  },
  imagePlaceholder: {
    flex: 1,
    backgroundColor: '#1E1E2E',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardContent: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 24,
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  cardText: {
    fontSize: 17,
    lineHeight: 26,
    color: '#D1D5DB',
    marginBottom: 16,
  },
  highlightContainer: {
    marginVertical: 8,
  },
  highlightedText: {
    fontSize: 17,
    lineHeight: 26,
    color: '#1F2937',
    backgroundColor: '#99F6E4', // Mint green like Noom
    paddingHorizontal: 4,
    paddingVertical: 2,
  },
  audioPlayer: {
    alignItems: 'center',
    marginTop: 32,
  },
  playButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  audioDuration: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  promptsContainer: {
    marginTop: 16,
  },
  promptItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2D2D3D',
  },
  promptText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 12,
  },
  bottomSection: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4B5563',
    marginHorizontal: 4,
  },
  dotActive: {
    backgroundColor: '#FFFFFF',
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  dotCompleted: {
    backgroundColor: '#8B5CF6',
  },
  ctaButton: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 18,
    borderRadius: 30,
    alignItems: 'center',
  },
  ctaText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
});

export default PaginatedLesson;


// Example usage with lesson data:
/*
const LESSON_1_CARDS: LessonCard[] = [
  {
    id: 1,
    type: 'intro',
    title: 'Fear',
    content: 'Today we\'re going to talk about fear. Not the kind that keeps you safe from danger—the kind that keeps you stuck.',
    image: 'lesson1_intro.jpg',
    ctaText: 'LET\'S GO',
  },
  {
    id: 2,
    type: 'content',
    content: 'Fear shows up in creative work wearing different disguises. Sometimes it looks like perfectionism. Sometimes it looks like "I need to do more research first."',
    highlightedContent: 'Fear loves to dress up as something productive.',
    ctaText: 'OKAY',
  },
  {
    id: 3,
    type: 'content',
    content: 'The goal isn\'t to eliminate fear. That\'s impossible. The goal is to recognize it and move anyway.',
    highlightedContent: 'Action despite fear is the definition of courage.',
    ctaText: 'GOT IT',
  },
  {
    id: 4,
    type: 'audio',
    title: 'Listen: Fear Breakthrough',
    content: 'This 12-minute audio will help you identify where fear is hiding in your current work.',
    audioUrl: 'lesson1_audio.mp3',
    audioDuration: '12 min',
    ctaText: 'LISTENED',
  },
  {
    id: 5,
    type: 'exercise',
    title: 'Your Turn',
    content: 'Now it\'s time to apply what you learned. Tap each prompt to complete your Fear Breakthrough exercise:',
    exercisePrompts: [
      '1. Name the task you\'ve been avoiding',
      '2. What\'s the worst that could happen?',
      '3. What\'s the smallest first step?',
    ],
    ctaText: 'DONE',
  },
  {
    id: 6,
    type: 'complete',
    title: 'Nice work!',
    content: 'You\'ve completed Lesson 1. Tomorrow, we\'ll tackle Resistance—the sneaky patterns that pull you away from important work.',
    highlightedContent: 'Your micro-action for today: Take that smallest first step you identified.',
    ctaText: 'I\'M READY',
  },
];
*/
