// EnergyCheckIn.tsx
// Add this to your Home screen - appears before the lesson card if user hasn't checked in today

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';

interface EnergyCheckInProps {
  onComplete: (level: number) => void;
  userName: string;
}

const ENERGY_LEVELS = [
  { level: 1, emoji: '😴', label: 'Exhausted', color: '#EF4444', message: "That's okay. We'll keep it light today." },
  { level: 2, emoji: '😔', label: 'Low', color: '#F97316', message: "Small wins still count. Let's do this." },
  { level: 3, emoji: '😐', label: 'Okay', color: '#EAB308', message: "Steady works. One step at a time." },
  { level: 4, emoji: '😊', label: 'Good', color: '#22C55E', message: "Nice! Let's make it count." },
  { level: 5, emoji: '🔥', label: 'Fired Up', color: '#8B5CF6', message: "Let's go! Time to ship." },
];

export const EnergyCheckIn: React.FC<EnergyCheckInProps> = ({ onComplete, userName }) => {
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const [showMessage, setShowMessage] = useState(false);

  const handleSelect = (level: number) => {
    setSelectedLevel(level);
    setShowMessage(true);
    
    // Auto-dismiss after showing message
    setTimeout(() => {
      onComplete(level);
    }, 1500);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  if (showMessage && selectedLevel) {
    const selected = ENERGY_LEVELS.find(e => e.level === selectedLevel);
    return (
      <View style={styles.container}>
        <View style={styles.messageContainer}>
          <Text style={styles.emoji}>{selected?.emoji}</Text>
          <Text style={styles.message}>{selected?.message}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>{getGreeting()}, {userName}</Text>
      <Text style={styles.question}>How's your energy today?</Text>
      
      <View style={styles.levelsContainer}>
        {ENERGY_LEVELS.map((item) => (
          <TouchableOpacity
            key={item.level}
            style={[
              styles.levelButton,
              selectedLevel === item.level && { borderColor: item.color, borderWidth: 2 }
            ]}
            onPress={() => handleSelect(item.level)}
            activeOpacity={0.7}
          >
            <Text style={styles.levelEmoji}>{item.emoji}</Text>
            <Text style={styles.levelLabel}>{item.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    marginBottom: 16,
  },
  greeting: {
    fontSize: 16,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  question: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 24,
  },
  levelsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  levelButton: {
    alignItems: 'center',
    padding: 12,
    borderRadius: 16,
    backgroundColor: '#1E1E2E',
    minWidth: 64,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  levelEmoji: {
    fontSize: 28,
    marginBottom: 4,
  },
  levelLabel: {
    fontSize: 11,
    color: '#9CA3AF',
    textAlign: 'center',
  },
  messageContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  message: {
    fontSize: 18,
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: '500',
  },
});

export default EnergyCheckIn;
