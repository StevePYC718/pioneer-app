// EnhancedProfile.tsx
// Upgraded Profile screen with Headspace-style design

import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface ProfileStats {
  currentStreak: number;
  longestStreak: number;
  lessonsCompleted: number;
  totalMinutes: number;
  sprintsCompleted: number;
}

interface EnhancedProfileProps {
  userName: string;
  userEmail: string;
  joinDate: string;
  stats: ProfileStats;
  streakDays: boolean[]; // Last 7 days, true = completed
  onSignOut: () => void;
  onSettings: () => void;
}

// Streak calendar showing last 7 days
const StreakCalendar: React.FC<{ streakDays: boolean[] }> = ({ streakDays }) => {
  const getDayLabel = (daysAgo: number): string => {
    const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    const date = new Date();
    date.setDate(date.getDate() - (6 - daysAgo));
    return days[date.getDay()];
  };

  return (
    <View style={styles.streakCalendar}>
      <Text style={styles.streakCalendarTitle}>This Week</Text>
      <View style={styles.streakDaysContainer}>
        {streakDays.map((completed, index) => (
          <View key={index} style={styles.streakDayItem}>
            <Text style={styles.streakDayLabel}>{getDayLabel(index)}</Text>
            <View
              style={[
                styles.streakDayCircle,
                completed && styles.streakDayCompleted,
                index === 6 && styles.streakDayToday,
              ]}
            >
              {completed && (
                <Ionicons name="checkmark" size={14} color="#FFFFFF" />
              )}
            </View>
          </View>
        ))}
      </View>
    </View>
  );
};

// Progress badge component
const ProgressBadge: React.FC<{
  icon: string;
  label: string;
  value: string | number;
  color: string;
}> = ({ icon, label, value, color }) => (
  <View style={styles.progressBadge}>
    <View style={[styles.badgeIconContainer, { backgroundColor: color + '20' }]}>
      <Ionicons name={icon as any} size={24} color={color} />
    </View>
    <Text style={styles.badgeValue}>{value}</Text>
    <Text style={styles.badgeLabel}>{label}</Text>
  </View>
);

export const EnhancedProfile: React.FC<EnhancedProfileProps> = ({
  userName,
  userEmail,
  joinDate,
  stats,
  streakDays,
  onSignOut,
  onSettings,
}) => {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Gradient Header */}
      <LinearGradient
        colors={['#F97316', '#FB923C', '#8B5CF6']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.headerGradient}
      >
        <TouchableOpacity style={styles.settingsButton} onPress={onSettings}>
          <Ionicons name="settings-outline" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        
        {/* Avatar */}
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Ionicons name="person" size={40} color="#6B7280" />
          </View>
        </View>
        
        <Text style={styles.userName}>{userName}</Text>
        <Text style={styles.joinDate}>Joined {joinDate}</Text>
      </LinearGradient>
      
      {/* Stats Section */}
      <View style={styles.statsSection}>
        <Text style={styles.sectionTitle}>Your Progress</Text>
        
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>🔥</Text>
            <Text style={styles.statValue}>{stats.currentStreak}</Text>
            <Text style={styles.statLabel}>Day Streak</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>✓</Text>
            <Text style={styles.statValue}>{stats.lessonsCompleted}</Text>
            <Text style={styles.statLabel}>Lessons</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>⏱</Text>
            <Text style={styles.statValue}>{stats.totalMinutes}</Text>
            <Text style={styles.statLabel}>Minutes</Text>
          </View>
          
          <View style={styles.statCard}>
            <Text style={styles.statEmoji}>🏆</Text>
            <Text style={styles.statValue}>{stats.longestStreak}</Text>
            <Text style={styles.statLabel}>Best Streak</Text>
          </View>
        </View>
      </View>
      
      {/* Streak Calendar */}
      <View style={styles.section}>
        <StreakCalendar streakDays={streakDays} />
      </View>
      
      {/* Journey Progress */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Journey Progress</Text>
        
        <View style={styles.journeyCard}>
          <View style={styles.journeyHeader}>
            <Text style={styles.journeyLabel}>90-Day Journey</Text>
            <Text style={styles.journeyPercent}>
              {Math.round((stats.lessonsCompleted / 27) * 100)}%
            </Text>
          </View>
          
          <View style={styles.progressBarContainer}>
            <View
              style={[
                styles.progressBarFill,
                { width: `${(stats.lessonsCompleted / 27) * 100}%` },
              ]}
            />
          </View>
          
          <View style={styles.journeyMilestones}>
            <View style={styles.milestone}>
              <View style={[styles.milestoneMarker, stats.sprintsCompleted >= 3 && styles.milestoneComplete]} />
              <Text style={styles.milestoneLabel}>Phase 1</Text>
            </View>
            <View style={styles.milestone}>
              <View style={[styles.milestoneMarker, stats.sprintsCompleted >= 6 && styles.milestoneComplete]} />
              <Text style={styles.milestoneLabel}>Phase 2</Text>
            </View>
            <View style={styles.milestone}>
              <View style={[styles.milestoneMarker, stats.sprintsCompleted >= 9 && styles.milestoneComplete]} />
              <Text style={styles.milestoneLabel}>Phase 3</Text>
            </View>
          </View>
        </View>
      </View>
      
      {/* Account Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        
        <View style={styles.accountCard}>
          <View style={styles.accountRow}>
            <Ionicons name="mail-outline" size={20} color="#9CA3AF" />
            <Text style={styles.accountText}>{userEmail}</Text>
          </View>
          
          <TouchableOpacity style={styles.accountRow}>
            <Ionicons name="notifications-outline" size={20} color="#9CA3AF" />
            <Text style={styles.accountText}>Notification Settings</Text>
            <Ionicons name="chevron-forward" size={20} color="#6B7280" />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.accountRow}>
            <Ionicons name="help-circle-outline" size={20} color="#9CA3AF" />
            <Text style={styles.accountText}>Help & Support</Text>
            <Ionicons name="chevron-forward" size={20} color="#6B7280" />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Sign Out Button */}
      <TouchableOpacity style={styles.signOutButton} onPress={onSignOut}>
        <Text style={styles.signOutText}>Sign Out</Text>
      </TouchableOpacity>
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>Pioneer Your Creative v1.0</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F1A',
  },
  headerGradient: {
    paddingTop: 60,
    paddingBottom: 40,
    alignItems: 'center',
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  settingsButton: {
    position: 'absolute',
    top: 60,
    right: 20,
    padding: 8,
  },
  avatarContainer: {
    marginBottom: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1E1E2E',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  userName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  joinDate: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  statsSection: {
    paddingHorizontal: 20,
    marginTop: -20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 16,
    marginTop: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: (SCREEN_WIDTH - 52) / 2,
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  statEmoji: {
    fontSize: 24,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 32,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  statLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
  },
  section: {
    paddingHorizontal: 20,
  },
  streakCalendar: {
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  streakCalendarTitle: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 16,
  },
  streakDaysContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  streakDayItem: {
    alignItems: 'center',
  },
  streakDayLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 8,
  },
  streakDayCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#2D2D3D',
    alignItems: 'center',
    justifyContent: 'center',
  },
  streakDayCompleted: {
    backgroundColor: '#22C55E',
  },
  streakDayToday: {
    borderWidth: 2,
    borderColor: '#8B5CF6',
  },
  journeyCard: {
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  journeyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  journeyLabel: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  journeyPercent: {
    fontSize: 16,
    fontWeight: '600',
    color: '#8B5CF6',
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: '#2D2D3D',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 16,
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#8B5CF6',
    borderRadius: 4,
  },
  journeyMilestones: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  milestone: {
    alignItems: 'center',
  },
  milestoneMarker: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#2D2D3D',
    marginBottom: 4,
  },
  milestoneComplete: {
    backgroundColor: '#22C55E',
  },
  milestoneLabel: {
    fontSize: 11,
    color: '#6B7280',
  },
  accountCard: {
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2D2D3D',
    overflow: 'hidden',
  },
  accountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2D2D3D',
  },
  accountText: {
    flex: 1,
    fontSize: 15,
    color: '#D1D5DB',
    marginLeft: 12,
  },
  signOutButton: {
    marginHorizontal: 20,
    marginTop: 24,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#EF4444',
    alignItems: 'center',
  },
  signOutText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#EF4444',
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  footerText: {
    fontSize: 12,
    color: '#4B5563',
  },
  progressBadge: {
    alignItems: 'center',
    flex: 1,
  },
  badgeIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  badgeValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  badgeLabel: {
    fontSize: 12,
    color: '#9CA3AF',
  },
});

export default EnhancedProfile;
