// EnhancedHomeScreen.tsx
// Updated Home screen with energy check-in, Co-Pilot access, and improved layout

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import EnergyCheckIn from './EnergyCheckIn';

interface Lesson {
  id: number;
  title: string;
  subtitle: string;
  duration: string;
  sprintNumber: number;
  lessonNumber: number;
}

interface EnhancedHomeScreenProps {
  userName: string;
  currentStreak: number;
  currentLesson: Lesson;
  todayMicroAction?: string;
  hasCheckedInToday: boolean;
  lessonProgress: number; // 0-3 for Sprint 1
  onStartLesson: () => void;
  onOpenCoPilot: () => void;
  onEnergyCheckIn: (level: number) => void;
}

export const EnhancedHomeScreen: React.FC<EnhancedHomeScreenProps> = ({
  userName,
  currentStreak,
  currentLesson,
  todayMicroAction,
  hasCheckedInToday,
  lessonProgress,
  onStartLesson,
  onOpenCoPilot,
  onEnergyCheckIn,
}) => {
  const [showEnergyCheckIn, setShowEnergyCheckIn] = useState(!hasCheckedInToday);

  const handleEnergyComplete = (level: number) => {
    onEnergyCheckIn(level);
    setTimeout(() => {
      setShowEnergyCheckIn(false);
    }, 1500);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  // If energy check-in needed, show that first
  if (showEnergyCheckIn) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <View />
          <TouchableOpacity style={styles.streakBadge}>
            <Text style={styles.streakEmoji}>🔥</Text>
            <Text style={styles.streakText}>{currentStreak}d</Text>
          </TouchableOpacity>
        </View>
        <EnergyCheckIn
          userName={userName}
          onComplete={handleEnergyComplete}
        />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>{getGreeting()},</Text>
          <Text style={styles.userName}>{userName}</Text>
        </View>
        <TouchableOpacity style={styles.streakBadge}>
          <Text style={styles.streakEmoji}>🔥</Text>
          <Text style={styles.streakText}>{currentStreak}d</Text>
        </TouchableOpacity>
      </View>

      {/* Main Lesson Card */}
      <View style={styles.lessonCard}>
        <Text style={styles.lessonLabel}>
          SPRINT {currentLesson.sprintNumber} • LESSON {currentLesson.lessonNumber}
        </Text>
        
        <Text style={styles.lessonTitle}>{currentLesson.title}</Text>
        <Text style={styles.lessonSubtitle}>{currentLesson.subtitle}</Text>
        
        {/* Play Button */}
        <TouchableOpacity style={styles.playButton} onPress={onStartLesson}>
          <LinearGradient
            colors={['#8B5CF6', '#7C3AED']}
            style={styles.playButtonGradient}
          >
            <Ionicons name="play" size={32} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
        
        <Text style={styles.duration}>{currentLesson.duration}</Text>
        
        <TouchableOpacity style={styles.beginButton} onPress={onStartLesson}>
          <Text style={styles.beginButtonText}>BEGIN LESSON</Text>
        </TouchableOpacity>
        
        {/* Progress Dots */}
        <View style={styles.progressSection}>
          <Text style={styles.progressLabel}>
            Day {lessonProgress + 1} of 3 • Sprint 1
          </Text>
          <View style={styles.progressDots}>
            {[0, 1, 2].map((index) => (
              <View
                key={index}
                style={[
                  styles.dot,
                  index <= lessonProgress && styles.dotActive,
                  index < lessonProgress && styles.dotCompleted,
                ]}
              />
            ))}
          </View>
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        {/* AI Co-Pilot Card */}
        <TouchableOpacity style={styles.coPilotCard} onPress={onOpenCoPilot}>
          <LinearGradient
            colors={['#F97316', '#FB923C']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.coPilotGradient}
          >
            <View style={styles.coPilotAvatar}>
              <View style={styles.coPilotEyes}>
                <View style={styles.coPilotEye} />
                <View style={styles.coPilotEye} />
              </View>
              <View style={styles.coPilotSmile} />
            </View>
          </LinearGradient>
          <View style={styles.coPilotContent}>
            <Text style={styles.coPilotTitle}>Talk to Co-Pilot</Text>
            <Text style={styles.coPilotSubtitle}>Feeling stuck? Get unstuck.</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#6B7280" />
        </TouchableOpacity>

        {/* Today's Micro-Action (if available) */}
        {todayMicroAction && (
          <View style={styles.microActionCard}>
            <View style={styles.microActionHeader}>
              <Ionicons name="flash" size={20} color="#F59E0B" />
              <Text style={styles.microActionLabel}>Today's Micro-Action</Text>
            </View>
            <Text style={styles.microActionText}>{todayMicroAction}</Text>
            <TouchableOpacity style={styles.microActionButton}>
              <Text style={styles.microActionButtonText}>Mark Complete</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Motivation Section */}
      <View style={styles.motivationCard}>
        <Text style={styles.motivationQuote}>
          "Action despite fear is the definition of courage."
        </Text>
        <Text style={styles.motivationSource}>— Sprint 1, Lesson 1</Text>
      </View>

      <View style={styles.bottomPadding} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0F1A',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  greeting: {
    fontSize: 16,
    color: '#9CA3AF',
  },
  userName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  streakBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E1E2E',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#F97316',
  },
  streakEmoji: {
    fontSize: 16,
    marginRight: 4,
  },
  streakText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  lessonCard: {
    marginHorizontal: 20,
    backgroundColor: '#1E1E2E',
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  lessonLabel: {
    fontSize: 12,
    color: '#9CA3AF',
    letterSpacing: 1,
    marginBottom: 8,
  },
  lessonTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
  },
  lessonSubtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  playButton: {
    marginBottom: 12,
  },
  playButtonGradient: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: 'rgba(139, 92, 246, 0.3)',
  },
  duration: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 20,
  },
  beginButton: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 16,
    paddingHorizontal: 48,
    borderRadius: 30,
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  beginButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  progressSection: {
    alignItems: 'center',
  },
  progressLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 8,
  },
  progressDots: {
    flexDirection: 'row',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#4B5563',
    marginHorizontal: 4,
  },
  dotActive: {
    backgroundColor: '#FFFFFF',
  },
  dotCompleted: {
    backgroundColor: '#8B5CF6',
  },
  quickActions: {
    paddingHorizontal: 20,
    marginTop: 24,
  },
  coPilotCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  coPilotGradient: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  coPilotAvatar: {
    alignItems: 'center',
  },
  coPilotEyes: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  coPilotEye: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#1F2937',
    marginHorizontal: 4,
  },
  coPilotSmile: {
    width: 12,
    height: 6,
    borderBottomLeftRadius: 6,
    borderBottomRightRadius: 6,
    borderWidth: 2,
    borderTopWidth: 0,
    borderColor: '#1F2937',
  },
  coPilotContent: {
    flex: 1,
    marginLeft: 16,
  },
  coPilotTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  coPilotSubtitle: {
    fontSize: 13,
    color: '#9CA3AF',
  },
  microActionCard: {
    backgroundColor: '#1E1E2E',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  microActionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  microActionLabel: {
    fontSize: 12,
    color: '#F59E0B',
    fontWeight: '600',
    marginLeft: 8,
    letterSpacing: 0.5,
  },
  microActionText: {
    fontSize: 15,
    color: '#D1D5DB',
    lineHeight: 22,
    marginBottom: 16,
  },
  microActionButton: {
    backgroundColor: '#2D2D3D',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  microActionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  motivationCard: {
    marginHorizontal: 20,
    marginTop: 24,
    padding: 20,
    borderLeftWidth: 3,
    borderLeftColor: '#8B5CF6',
    backgroundColor: '#1E1E2E',
    borderRadius: 8,
  },
  motivationQuote: {
    fontSize: 15,
    color: '#D1D5DB',
    fontStyle: 'italic',
    lineHeight: 22,
    marginBottom: 8,
  },
  motivationSource: {
    fontSize: 12,
    color: '#6B7280',
  },
  bottomPadding: {
    height: 100,
  },
});

export default EnhancedHomeScreen;
